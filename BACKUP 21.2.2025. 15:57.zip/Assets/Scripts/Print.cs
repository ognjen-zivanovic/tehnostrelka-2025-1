using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Print : MonoBehaviour
{
    public void PrintString(string s) {
        Debug.Log(s);
    }
}
