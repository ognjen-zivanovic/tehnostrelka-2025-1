using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaterBoundsInfo : MonoBehaviour
{
    public static float minX = -1.0f;
    public static float maxX = 1.0f;
    public static float minZ = -1.0f;
    public static float maxZ = 1.0f;
}
